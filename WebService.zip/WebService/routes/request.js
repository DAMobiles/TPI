var mysql = require('mysql');
var conexion = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : 'Debaisu',
	database : 'aplicaciones'
});

exports.verPublicacionesGenerales = function (req, res) {
	conexion.query("call verPublicacionesGenerales", function selectCb(err, details, fields) {
		if (err) {
			console.log("Error: " + err.message);
			throw err;
		} else { res.json(details[0]); }
	});
};